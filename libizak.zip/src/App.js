
import './App.css';
import React from 'react';
import Main from './Pages/Main';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Project from './Pages/Project';
import Contact from './Pages/Contact';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={ <Main id="Main" /> } />
        <Route path="/:projectUrl" element={<Project />} />
        <Route path="/contact" element={<Contact />} />
      </Routes> 
    </BrowserRouter>
  );
}

export default App;
